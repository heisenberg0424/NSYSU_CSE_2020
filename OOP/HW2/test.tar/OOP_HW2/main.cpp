#include "mytar.h"
using namespace std;

int main(int argc, char **argv)
{
    cout<<"argc= "<<argc<<endl<<"argv= "<<argv[1]<<endl;
    mytar tar(const_cast<const char*>(argv[1]));
    tar.startRead();
}