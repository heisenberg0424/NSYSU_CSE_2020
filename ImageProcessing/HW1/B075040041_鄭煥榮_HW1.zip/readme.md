OS:
Ubuntu 20.04 LTS
Python 3.8.5

Package used:
Tkinter
cv2
numpy
matplotlib
PIL

How to install:
pip3 install python-tk
pip3 install opencv-python
pip install numpy
python -m pip install -U matplotlib
pip install pil
