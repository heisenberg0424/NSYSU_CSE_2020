OS:
Ubuntu 20.04 LTS
Python 3.8.5

###Suggestion
U have to reload the picture after using the saving button
And the reset button will help u reset the modified picture
###
Package used:
Tkinter
cv2
numpy
matplotlib
PIL

How to install:
pip3 install python-tk
pip3 install opencv-python
pip install numpy
python -m pip install -U matplotlib
pip install pil
